<?php include 'seller_header.php'; ?>
<div class="container my-4">
   <h3>Orders for My Books</h3>
   <div class="alert alert-secondary">(пока не реализовано: тут будут отображаться заказы по товарам, где seller_id = вы)</div>
</div>
